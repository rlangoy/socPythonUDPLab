#include "mbed.h"

#define MAX_LED_SW 3
DigitalOut  led[]= {PA_9,PC_7,PB_6,PA_7,PA_6,PA_5,PB_5,PB_4};
BusIn Switches(PA_0,PA_1,PA_4,PB_0,PC_1,PC_0,PA_10,PB_3);
Ticker tickerReadSwitch; // define debounce timer

static int oldSWValues=0;

void chkButtonPushed()
{
    int swValue=Switches.read();
    if(swValue!=oldSWValues) {
        oldSWValues=swValue;
        printf("$SW");
        for(int i=0; i<MAX_LED_SW; i++)
            printf(",%d",! ((swValue>>i) & 0x1) );
        printf("\r\n");
    }
}

int main()
{
    tickerReadSwitch.attach(&chkButtonPushed,.1);

    char buffer[80];
    for(int i=0; i<8; i++)
        led[i]=1; // Start by turning all leds off

    while (true) {
        scanf("%[^\r\n]s",buffer);  // Read a whole line
        getchar();                             // remove "\r\n" from stio

        //vars used to split the CSV string
        int count = 0;  // counter
        char* tok;      // holds the string element

        tok = strtok(buffer, ",");   // get the first element in string before the ","
        if (strcmp(tok,"$LED")==0) {
            while((tok != NULL) && (count< MAX_LED_SW)) {
                tok = strtok(NULL, ",");        // get the next token (next string item)
                led[count]=! atoi(tok);         // convert value to int invert and update led status
                count++;                       // inc counter
            }
        }
    }
}